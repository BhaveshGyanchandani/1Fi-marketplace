# 1Fi Marketplace — SDE Intern Assignment

A standalone implementation of the **1Fi Marketplace** section added to the
existing Shop page, built with **Vite + React + TypeScript + Tailwind CSS**.

## Setup

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build to dist/
```

No environment variables or backend setup needed — everything runs client-side.

## What this is

The Shop page has three tabs: **Top Brands**, **Nearby Stores** (both blank
placeholders, per the assignment brief), and **1Fi Marketplace** (fully built).
The Marketplace flow: browse products → open a product → pick a variant → pick
an EMI tenure → confirm.

## Architecture

- **Routing**: `react-router-dom`, one route per screen (`/shop/top-brands`,
  `/shop/nearby-stores`, `/shop/marketplace`, `/shop/marketplace/:productId`)
- **Styling**: Tailwind CSS, themed with 1Fi's real brand purple (`#712CDC`)
- **Data layer**: `lib/mock-server/` stands in for a backend — see
  "Mocked vs. real" below
- **State**: local component state only (`useState`/`useMemo`); no Redux —
  the selection flow (variant → EMI plan → CTA) is short-lived and scoped to
  one screen, so a global store would be overengineering for this feature
- **Shared types**: `Product`, `ProductVariant`, `EMIPlan` in `lib/types.ts`,
  imported everywhere — never redefined per component
- **Components**: `ProductCard`, `EMIPlanCard`, and friends are pure/presentational
  and reusable outside the screens that first needed them

Full folder structure, data model, and the state-flow diagram are documented in
[`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md). [`docs/PROJECT.md`](./docs/PROJECT.md)
and [`docs/SKILL.md`](./docs/SKILL.md) capture the product understanding and
design conventions this was built against, before any code was written.

### One deviation from `docs/ARCHITECTURE.md`

The docs were originally written for a Next.js App Router project (with
`/app/api` route handlers as the mock API layer). This submission targets
**Vite**, which has no server runtime, so:

- Next.js pages → `react-router-dom` routes under `src/pages/`
- Next.js API routes → `src/lib/mock-server/marketplaceApi.ts`, a module that
  exposes the same three operations (`fetchProducts`, `fetchProductById`,
  `fetchEmiPlans`), the same `{ data } / { error }` response envelope, and the
  same artificial network latency a real `fetch()` call would have

Everything else in `docs/ARCHITECTURE.md` — folder layout, data models, API
contract, state flow, component list — was followed as written.

## Mocked vs. real

| Piece | Status |
|---|---|
| Product catalog (6 phones, 2–3 variants each) | Mock data, `lib/data/products.json` |
| EMI plan calculation | Real logic: `priceInr ÷ tenureMonths`, tenures scaled to price point (`lib/mock-server/emiEngine.ts`) — not real underwriting, but not a static lookup table either |
| "API" layer | Simulated: async functions with a 500ms delay and a `{ data } / { error }` shape, not real HTTP. Swapping in a real backend later means changing `marketplaceApi.ts` only — no component or hook would need to change |
| Mutual-fund eligibility / "Limit" check | Not implemented. The assignment scope excludes real pledging/limit logic; this build assumes the user is already eligible |
| Checkout / payment | Not implemented. "Proceed" ends in an in-page confirmation summary, not a real payment flow |

## Assumptions made about 1Fi's design system

The only screens available for reference were the Shop page (both tabs) and
the "Pay using 1Fi" payment screen — not the full app or its style guide. So:

- **Confirmed from the reference screenshots and reproduced directly**: brand
  color `#712CDC`, the hero banner (badge, headline, subtext), the pill-style
  tab switcher with its lavender track and active-tab underline, the search
  bar below the tabs, the bottom nav order (Home / Shop / EMI Dues / Limit /
  Profile), and the circular-icon-button + arrow-pill-CTA pairing from the
  payment screen
- **Explicitly NOT reproduced**: the hero's product-collage illustration
  (phone/laptop/car/bike bursting from a shopping bag) is 1Fi's own marketing
  artwork — this build uses a plain placeholder graphic instead of a
  lookalike substitute
- **Assumed as reasonable fintech-app defaults, not verified**: exact spacing
  scale, card border-radius (used 16px), font family (used a system-font
  stack resembling Inter), and icon set (hand-drawn inline SVGs, since the
  real icon set wasn't available)
- **EMI plan framing**: no interest rate or credit-score messaging is shown,
  since 1Fi's real model is 0%-interest EMI collateralized against mutual
  funds, not a CIBIL-checked loan — see `docs/SKILL.md` for the reasoning
- **Plan-first vs. amount-first checkout**: the real "Pay using 1Fi" screen
  is an any-amount payment flow (enter a rupee amount, then EMI is computed).
  This Marketplace is plan-first instead (pick a product → variant → EMI
  tenure), per the assignment brief's explicit ask for "ability to select an
  EMI plan." Only the payment screen's *visual language* (icon button + pill
  CTA, header style) was carried over — not its amount-entry interaction.

None of the above is presented as verified fact anywhere in the app itself —
only here, explicitly, as the assumptions they are. See
[`docs/UPDATE.md`](./docs/UPDATE.md) for the specific gap analysis this round
of changes closed.

## Project structure

```
src/
├── pages/shop/                 # route-level screens
│   ├── TopBrandsPage.tsx       # blank stub, per brief
│   ├── NearbyStoresPage.tsx    # blank stub, per brief
│   └── marketplace/
│       ├── MarketplaceListPage.tsx
│       └── ProductDetailPage.tsx
├── components/
│   ├── shop/                   # ShopShell, ShopHero, ShopTabs, SearchBar, BottomNav
│   ├── marketplace/             # ProductCard, VariantSelector, EMIPlanCard, etc.
│   └── ui/                      # Button, Skeleton, ErrorState, EmptyState
├── lib/
│   ├── types.ts
│   ├── data/products.json
│   ├── mock-server/             # emiEngine.ts, marketplaceApi.ts
│   └── hooks/                   # useProducts, useProduct, useEmiPlans
└── docs/                        # SKILL.md, PROJECT.md, ARCHITECTURE.md, PROMPT.md, UPDATE.md
```

## Loading / error / empty states

Every async screen (product listing, product detail, EMI plan selector)
implements all three: a skeleton while loading, an error state with a Retry
button on failure, and an empty state when there's genuinely nothing to show.
