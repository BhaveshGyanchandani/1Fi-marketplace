/**
 * The Shop page banner — a single image (badge, headline, subtext, and
 * product illustration are all baked into the image itself, so no text is
 * rendered here). Wrapper fixed at 532x354, centered horizontally via
 * mx-auto (as a block) with the image centered inside it via flex
 * justify-center. The image itself stays at its own fixed 582.2x390.98 size
 * (intentionally larger than the wrapper, clipped by overflow-hidden, so it
 * bleeds slightly past the wrapper's edges rather than being squeezed to fit).
 *
 * Note: this drops the earlier -mx-4/md/lg bleed-to-screen-edge classes —
 * negative horizontal margins on the same element as mx-auto/justify-center
 * fight the centering (they pull the box off-axis), so centering and that
 * edge-bleed behavior can't both live on this one wrapper. If edge-to-edge
 * bleed still matters, it needs to move to an ancestor that ISN'T also the
 * thing being centered.
 *
 * Drop your downloaded banner image at the path below (or update
 * BANNER_IMAGE_SRC to wherever you saved it).
 */
const BANNER_IMAGE_SRC = '/hero-illustration.webp';

export function ShopHero() {
  return (
    <div className="overflow-hidden w-[532px] h-[354px] flex justify-center items-center mx-auto">
      <img
        src={BANNER_IMAGE_SRC}
        alt="Shop today, pay later using mutual funds — no-cost EMIs, no credit score required"
        className="w-[582.2px] h-[390.98px] object-cover"
        onError={(e) => {
          // Fails gracefully if the image hasn't been added yet — hides
          // the broken-image icon instead of showing it, and leaves a
          // placeholder box the same shape so layout doesn't jump.
          const img = e.currentTarget as HTMLImageElement;
          img.style.display = 'none';
          const placeholder = img.nextElementSibling as HTMLElement | null;
          if (placeholder) placeholder.style.display = 'flex';
        }}
      />
      {/* Fallback shown only if the image fails to load — keeps the same
          fixed size/shape so the page doesn't jump once the real image is added. */}
      <div className="hidden w-[582.2px] h-[390.98px] bg-primary items-center justify-center text-white/60 text-sm">
        Banner image not found at {BANNER_IMAGE_SRC}
      </div>
    </div>
  );
}
